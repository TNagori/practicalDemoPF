package com.payment.testing.payments;

import com.payment.testing.page.DemoVersionPage;
import com.payment.testing.page.PaymentDetails;
import com.payment.testing.page.PaymentOverview;
import com.payment.testing.page.PaymentPage;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.util.concurrent.TimeUnit;

import static org.openqa.selenium.support.ui.ExpectedConditions.*;

public class PaymentUnitTest {
    private PracticalPostFinance practicalPostFinance;


    @Before
    public void testPaymentPage() throws InterruptedException {
        WebDriver webDriver = PaymentUnitTest.webDriver();
        webDriver().manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
        PracticalPostFinance practicalPostFinance1 = new PracticalPostFinance(webDriver);
        PaymentPage page = practicalPostFinance1.goToPaymentSamplePage();
        page.setIBAN("CH03").selectSample().clickItem();

    }

    @Test
    public void testPaymentOverviewAndNavigateBack() throws InterruptedException {
        WebDriver webDriver = PaymentUnitTest.webDriver();
        PracticalPostFinance practicalPostFinance = new PracticalPostFinance(webDriver);

        // Go to Payment Details page
        PaymentDetails page1 = practicalPostFinance.goToPaymentDetails();
        page1.scrollDown().getAmount();
        page1.scrollBottom().getAmount();

        // Go to Payment Overview page
        PaymentOverview page2 = practicalPostFinance.goToPaymentOverView();
        page2.getOverviewAmount();

        // Assert or perform actions on Payment Overview page
        page2.getOverviewAmount();
        page2.setSend();

        // Go to Demo Version Page
        DemoVersionPage page3 = practicalPostFinance.landedToDemoVersionPage();
        page3.getErrorMessage();

    }
        @After
    public void closeCurrentBrowser() {
        practicalPostFinance.getWebDriver().close();
    }

    public static WebDriver webDriver() {
        try {
            File file = new File("C:\\Exense\\chromedriver.exe");
            System.setProperty("webdriver.chrome.driver", file.getAbsolutePath());
            ChromeOptions co = new ChromeOptions();
            co.setBinary("C:\\Exense\\chrome-win64\\chrome.exe");
            return new ChromeDriver(co);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}


