package com.payment.testing.payments;

import org.junit.Assert;
import org.junit.Test;
import step.functions.io.Output;
import step.handlers.javahandler.KeywordRunner;

import javax.json.JsonObject;
import java.util.HashMap;
import java.util.Map;

public class PaymentSeleniumKeywordTest {
    @Test
    public void PaymentSeleniumKeywordTest() throws Exception {
        Map<String, String> properties = new HashMap<>();
        KeywordRunner.ExecutionContext ctx = KeywordRunner.getExecutionContext(properties, PaymentKeyWords.class);
        ctx.run("Payments_Selenium_Keyword", "{}");
    }

    @Test
    public void paymentSeleniumSingleKeywordsTest() throws Exception {
        Map<String, String> properties = new HashMap<>();
        KeywordRunner.ExecutionContext ctx = KeywordRunner.getExecutionContext(properties, PaymentKeyWords.class);
        ctx.run("Navigate_To_PaymentPage", "{}");
        ctx.run("Payment_Details", "{}");
        ctx.run("Check_PaymentOverview", "{}");
        ctx.run("Navigate_Back", "{}");
        ctx.run("Amount_Verify", "{}");
        ctx.run("Close_Browser", "{}");

    }


    private static class PaymentKeyWords {
    }
}
