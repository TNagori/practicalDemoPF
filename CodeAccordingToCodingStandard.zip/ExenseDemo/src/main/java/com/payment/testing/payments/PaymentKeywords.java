package com.payment.testing.payments;

import com.payment.testing.page.PaymentPage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import step.handlers.javahandler.AbstractKeyword;
import step.handlers.javahandler.Keyword;

import java.io.File;

public class PaymentKeywords extends AbstractKeyword {
    @Keyword(name="Payments_Selenium_Keyword")
    public void paymentSeleniumFullKeyword() throws InterruptedException {
        testSampleTemplate();
        testPaymentDetails();
        testPaymentOverview();
        testDemoVersionPage();
        testPaymentAmount();
        closeBrowser();
    }
    //Individual Keywords per browser interactions

    @Keyword(name= "Navigate_To_PaymentPage")
    public void navigatePaymentPage() throws InterruptedException {
        WebDriver webDriver = PaymentKeywords.webDriver();
        PracticalPostFinance practicalPostFinance;
        practicalPostFinance = new PracticalPostFinance(webDriver);
        session.put(practicalPostFinance);
        String act = input.getString("act", "CH03");
        practicalPostFinance.goToPaymentSamplePage().setIBAN(act).selectSample().clickItem();
        }
    @Keyword(name="Payment_Details")
    public void paymentDetailsVerify() throws InterruptedException {
        PracticalPostFinance practicalPostFinance = session.get(PracticalPostFinance.class);
        practicalPostFinance.goToPaymentDetails().scrollDown().getAmount().strip();
        practicalPostFinance.goToPaymentDetails().scrollBottom().clickNext();

    }
    @Keyword(name="Check_PaymentOverview")
        public void paymentOverviewAmountVerify() {
            PracticalPostFinance practicalPostFinance = session.get(PracticalPostFinance.class);
            try {
                practicalPostFinance.goToPaymentOverView().getOverviewAmount().toString();
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
            finally {
                practicalPostFinance.goToPaymentOverView().setSend();
            }
            }
    @Keyword(name = "Navigate_Back")
    public void checkErrorAndNavigateBack() throws InterruptedException {
        PracticalPostFinance practicalPostFinance = session.get(PracticalPostFinance.class);
        practicalPostFinance.landedToDemoVersionPage().getErrorMessage().getBackToPayment();
        }
    @Keyword(name="Amount_Verify")
    public void checkAmount() throws InterruptedException {
        PracticalPostFinance practicalPostFinance = session.get(PracticalPostFinance.class);
        practicalPostFinance.amountVerify();
    }

    @Keyword(name = "Close_Browser")
    public void closeBrowser(){
        session.get(PracticalPostFinance.class).getWebDriver().close();
    }

    public static final WebDriver webDriver() {
        try {
            File file = new File("C:\\Exense\\chromedriver.exe");
            System.setProperty("webdriver.chrome.driver", file.getAbsolutePath());
            ChromeOptions co = new ChromeOptions();
            co.setBinary("C:\\Exense\\chrome-win64\\chrome.exe");
            return new ChromeDriver(co);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

        private void testSampleTemplate() throws InterruptedException {
            navigatePaymentPage();
        }
        private void testPaymentDetails() throws InterruptedException {
            paymentDetailsVerify();
        }
        private void testPaymentOverview() {
            paymentOverviewAmountVerify();
        }
        private void testDemoVersionPage() throws InterruptedException {
            checkErrorAndNavigateBack();
        }

        private void testPaymentAmount() throws InterruptedException {
            checkAmount();
        }







}

