package com.payment.testing.page;


import com.payment.testing.object.PageObject;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

@PageObject
public class PaymentDetails {
    public String amountProvided;
    private final WebDriver driver;

    public PaymentDetails(WebDriver driver) {
        this.driver = driver;
    }

    @FindBy(xpath = "//input[@id='formly_30_amount-input_debitAmount_0']")
    private WebElement amountFeed;

    @FindBy(xpath = "//button[@type=\"submit\"]")
    private WebElement clickNextButton;

    public PaymentDetails scrollDown(){
        JavascriptExecutor js = (JavascriptExecutor)driver;
        js.executeScript("window, scrollBy(0,250)","");
        return this;
    }
    public String getAmount() throws InterruptedException {
        Thread.sleep(1000);
        String amountProvided = amountFeed.getText();
        return amountFeed.getText();
    }


    public void clickNext() throws InterruptedException {
        Thread.sleep(2000);
        clickNextButton.click();
    }

    public PaymentDetails scrollBottom() {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window, scrollBy(0,400)", "");
        return this;
    }
}
