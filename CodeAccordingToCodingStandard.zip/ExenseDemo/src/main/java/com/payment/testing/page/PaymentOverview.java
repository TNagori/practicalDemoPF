package com.payment.testing.page;

import com.payment.testing.object.PageObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;


@PageObject
public class PaymentOverview {
    public String amountPresent;
    @FindBy(xpath = "//span[@class=\"ng-star-inserted\"][2]")
    public WebElement overviewAmount;

    @FindBy(xpath = "//button[@data-cy=\"send-button\"]")
    private WebElement clickSend;

    public PaymentOverview(WebDriver driver) {
    }

    public String getOverviewAmount() throws InterruptedException {
        Thread.sleep(1000);
        String amountPresent = overviewAmount.getText();
        return overviewAmount.getText();
    }
    public void setSend(){
        clickSend.click();
    }



}
//span[@class="ng-star-inserted"][2]