package com.payment.testing.page;


import com.payment.testing.object.PageObject;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;




@PageObject
public class PaymentPage {

    private final WebDriver driver;
    @FindBy(xpath = "//fpui-translate[@class=\"break-words whitespace-pre-line ng-star-inserted\"]")
    private WebElement fieldIBAN;

    @FindBy(id = "smart-bar-flyout")
    private WebElement selectSample;


    public PaymentPage setIBAN(String text) {
        fieldIBAN.click();
        Actions act = new Actions(driver);
        act.sendKeys(Keys.TAB).perform();
        act.sendKeys(text);
        return this;
    }

    public PaymentPage selectSample() {
        selectSample.click();
        return this;
         }

    public void clickItem() {
        Actions act = new Actions(driver);
        act.sendKeys(Keys.TAB).perform();
        act.click();
    }



    public PaymentPage(WebDriver driver) {
        this.driver = driver;

    }
}









