package com.payment.testing.payments;

import com.payment.testing.page.DemoVersionPage;
import com.payment.testing.page.PaymentDetails;
import com.payment.testing.page.PaymentOverview;
import com.payment.testing.page.PaymentPage;
import org.junit.Assert;
import org.openqa.selenium.*;


import org.openqa.selenium.support.PageFactory;



public class PracticalPostFinance {
    private static final String BASE_URL = "https://www.postfinance.ch/ap/ga/ob/html/finance/transfer/enter-payment";

    private final WebDriver driver;

    private final PaymentPage paymentPage;

    private final PaymentOverview paymentOverview;

    private final PaymentDetails paymentDetails;

    private final DemoVersionPage demoVersionPage;

    public PracticalPostFinance(WebDriver webDriver) {
        this.driver = webDriver;
        this.paymentPage = new PaymentPage(driver);
        this.paymentOverview = new PaymentOverview(driver);
        this.paymentDetails = new PaymentDetails(driver);
        this.demoVersionPage = new DemoVersionPage(driver);
    }


    public PaymentPage goToPaymentSamplePage() throws InterruptedException {
        driver.get(BASE_URL);
        driver.manage().window().maximize();
        Thread.sleep(3000);
        PageFactory.initElements(driver, paymentPage);
        return paymentPage;
    }

    public PaymentDetails goToPaymentDetails() {
        PageFactory.initElements(driver, paymentDetails);
        return paymentDetails;
    }

    public PaymentOverview goToPaymentOverView() {
        PageFactory.initElements(driver, paymentOverview);
        return paymentOverview;
    }

    public DemoVersionPage landedToDemoVersionPage() {
        PageFactory.initElements(driver, demoVersionPage);
        return demoVersionPage;
    }
    public WebDriver getWebDriver(){
        return driver;
    }
    public void amountVerify() throws InterruptedException {
        WebDriver driver = getWebDriver();
        PaymentDetails paymentDetails = new PaymentDetails(driver);
        PaymentOverview paymentOverview = new PaymentOverview(driver);

        String amountFromPaymentDetails = paymentDetails.getAmount();
        String amountFromPaymentOverview = String.valueOf(paymentOverview.getOverviewAmount());

        Assert.assertEquals("Values are not equal", amountFromPaymentDetails, amountFromPaymentOverview);

    }


}





