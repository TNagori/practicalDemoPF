package com.payment.testing.page;

import com.payment.testing.object.PageObject;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

@PageObject
public class DemoVersionPage {
    @FindBy (xpath = "//p[contains(text(),\"Demoversion\")]")
    private WebElement message;
    @FindBy(className="fpui-button cc-text-sm fpui-button--secondary fpui-button--normal ng-star-inserted")
    private WebElement clickBack ;

    public DemoVersionPage(WebDriver driver) {
    }


    public DemoVersionPage getErrorMessage() throws InterruptedException {
        Thread.sleep(1000);
        message.getText();
        return this;
    }
    public void getBackToPayment(){
        clickBack.click();
    }




}
